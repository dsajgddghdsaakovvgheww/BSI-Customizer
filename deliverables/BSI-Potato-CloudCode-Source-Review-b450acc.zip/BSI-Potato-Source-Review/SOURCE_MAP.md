# Exact source navigation

Paths/line numbers refer to the verified b450acc source members. These are entry points for review, not conclusions about the installed game.

| File | Line | Entry point |
| --- | ---: | --- |
| `src/shaders/PresentationHooks.cpp` | 281 | `struct GameCandidate {` |
| `src/shaders/PresentationHooks.cpp` | 350 | `struct GameDraw {` |
| `src/shaders/PresentationHooks.cpp` | 435 | `struct GameTransfer {` |
| `src/shaders/PresentationHooks.cpp` | 539 | `struct GameImageBinding {` |
| `src/shaders/PresentationHooks.cpp` | 697 | `bool installGlProcedure(unsigned provider,const char *name,void *target){` |
| `src/shaders/PresentationHooks.cpp` | 841 | `void discoverCurrentWgl(HDC dc,HGLRC context)noexcept{` |
| `src/shaders/PresentationHooks.cpp` | 909 | `void discoverCurrentEgl(unsigned provider,void *display,void *draw,void *read,void *context)noexcept{` |
| `src/shaders/PresentationHooks.cpp` | 964 | `void process(unsigned provider,` |
| `src/shaders/PresentationHooks.cpp` | 1306 | `void scan(){` |
| `src/shaders/GlTextureOverride.cpp` | 195 | `MipInspection inspectMips(` |
| `src/shaders/GlTextureOverride.cpp` | 332 | `bool GlTextureOverride::usage(` |
| `src/shaders/GlTextureOverride.cpp` | 383 | `bool GlTextureOverride::drawWrites(` |
| `src/shaders/GlTextureOverride.cpp` | 429 | `bool GlTextureOverride::transfer(` |
| `src/shaders/GlTextureOverride.cpp` | 565 | `unsigned GlTextureOverride::begin(` |
| `src/shaders/GlTextureOverride.cpp` | 668 | `void GlTextureOverride::end()` |
| `src/shaders/GlTextureOverride.cpp` | 130 | `Sampler readSampler(` |
| `src/shaders/GlTextureOverride.cpp` | 142 | `U privateSampler(` |
| `src/shaders/GlTextureProvenance.h` | 99 | `bool hasDependencies(` |
| `src/shaders/GlTextureProvenance.h` | 177 | `void discardPendingDrawWrites(` |
| `src/shaders/GlTextureProvenance.h` | 190 | `GlDeferredCopyResult deferCopy(GlContextIdentity key,const GlTextureUsage &usage,GlDeferredCopyCapture capture)` |
| `src/shaders/GlTextureProvenance.h` | 209 | `bool producer(` |
| `src/shaders/GlTextureProvenance.h` | 217 | `unsigned observe(` |
| `src/shaders/GlTextureProvenance.h` | 304 | `void resolvePending(` |
| `src/shaders/Runtime.cpp` | 111 | `void Runtime::setTexture(` |
| `src/shaders/Runtime.cpp` | 126 | `TextureRoute Runtime::textureRoute(` |
| `src/shaders/Runtime.cpp` | 130 | `bool Runtime::textureHookEntry(` |
| `src/shaders/Runtime.cpp` | 172 | `void Runtime::textureReport(` |
| `src/shaders/ShaderBridge.cpp` | 238 | `QVariantMap ShaderBridge::applyConfiguration(` |

Also read `GlProducerRoute.h`, `GlDrawCalls.h`, `GlDrawScope.h`, `EglDispatchScope.h`, `WglPbufferRegistry.h`, `GlTextureQuality.h` and `TextureQuality.h`.

The CPU-only runner exercises eight existing contracts, not Windows/pixels/UI. The supplied ordering, WGL/EGL and software-pixel sources are for constructing a minimal new regression; do not call them executed by this runner.
