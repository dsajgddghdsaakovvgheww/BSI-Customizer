# Focused Cloud Code review: live Potato sampling

## Requested result

Please review the included source offline. Return **one concrete, falsifiable next step**, preferably a small failing authored regression and a minimal patch. Do not provide another generic hook skeleton, infer game success from tests/counters, or rediscover the already-repaired v6 output/eligibility conflation.

For every finding use:

1. `file:function:line` and the exact predicate/state involved;
2. a minimal ordered API/resource/context sequence;
3. what is a source-confirmed defect versus an unsupported capability or game hypothesis;
4. an authored test that fails on this candidate, including native/Off and exclusion controls;
5. the smallest proposed change and its remaining limits.

If the included evidence cannot establish a new defect, say so and identify the smallest missing observation. Do not manufacture a fix to produce nonzero counters.

## What is in this ZIP

- All 49 `src/shaders/` files from the candidate, including hooks, GL inspection, provenance, Runtime, native Settings bridge and the independently written QML page.
- Selected CPU contract tests, Windows dispatch/ordering fixtures and software-pixel test sources.
- Licensed MinHook source and Vulkan API headers, with their original licenses. No built dependency libraries are included.
- Historical installed-v6 failure, v7 repair evidence, later package readback evidence, source map and per-file SHA-256/Git-blob provenance.
- `run_review_tests.py`: a small, independent runner for **eight CPU/public-state-double tests**. It needs Python 3 and a local C++17 compiler, not network, Qt, a GPU, a driver, emulator or game. It compiles only our authored tests. See its limits below.

This is **source for review**, not the Actions portable EXE, a full Customizer/release checkout, an installer, or something to copy into BlueStacks. Selected Qt/Windows/driver/pixel tests are supplied for reading, not claimed runnable by the CPU-only runner. Full module UI resources/build tooling are intentionally not included. The renderer code contains no Qt objects crossing into the render thread; only the separate small public-API Settings bridge depends on Qt.

No original Potato DLL, PF archive, player/provider/driver executable, extracted proprietary shader/QML/disassembly, account data, credentials, auth configuration, Git directory, process dump or raw frame trace is included. C++ shader source/constants and public API headers are text, not supplied player binaries.

## Exact source identity

Packaged candidate: **b450acc5304829b095052eec2751432c135ab7e7**.
Validated rendering implementation: **eafff51bb12f9551336393ef8d308b13f3393faa** (only documentation differs at the packaged commit).
Module capture identity: **gl-draw-write-footprint-v7**.

`MANIFEST.json` records each member's size and SHA-256. All included renderer, fixture and dependency source bytes are verified against GitHub's Git-blob identities at the packaged commit, rather than inferred from the workspace's current local HEAD. Follow-up documents and this review harness are explicitly labeled separately. No production code was changed to prepare this packet.

## Requirement that must not be weakened

**Live native Settings On/Off and integer strength 0–100**, with existing native Save/No/Discard. Source texture/sampler descriptors remain unchanged. An eligible native draw borrows private sampler bindings, invokes the original once, and restores bindings before returning. Off/zero is native sampling. The unchanged original DLL has no supported live-control ABI and is not the selected implementation.

Keep existing provider/display/context/observed-share, protection, foreign-window, resource generation/lifetime, color, selected-source/settings revision, TTL and capacity boundaries. Sharing or equal numeric GL names is not ownership. Do not adopt an unknown or protected route to raise counters.

Do not generate mipmaps, force filters or BASE_LEVEL, change source objects, blur/downscale a completed frame, map strength to native Display/DPI, add a proxy/loader-lock initializer, stack hook layers, or unload/unhook live callbacks. No external controller/IPC replaces the native Settings requirement.

## Known facts, with evidence categories kept separate

### Actual installed result: v6, negative

`docs/evidence/potato-installed-v6.json` transcribes the user's prior report, not a new remote inspection:

- Source 2e5e6a0b726cf84dbc36c8ee5d5dcf8dce2c4d19; 5,950 presentation frames.
- 303,884 process-wide **pre-route hook entries**, not a census of unique game draws.
- 11,663 sampler inspections, zero prepared Potato draws/bindings.
- 11,661 presentation-input observations with one color input each; only 2 linked-producer inspections, also zero bindings.
- Last presentation input: mutable RGB, 256x256, LINEAR, base/max 0/1000.
- Last linked-producer input: mutable RGBA8, 960x540, NEAREST, base/max 0/0. This was an inspected producer input; do not relabel it as a proven final presentation texture or a material texture.
- 11,630 queued copies: 11,361 unknown-output retirements at the old combined `draw-output-or-primitive-unavailable` site, 256 captured-destination writes, 10 missed/guarded/busy, 1 sharing change, 2 reconciliations; pending 0, peak 2.

The raw/inspected difference is a useful routing lead. It is **not** proof that the remaining 96% are material draws, nor that a particular source renderbuffer's producer was never hooked. A copy-retirement site is metadata accounting, not a GPU-write or missing-entry-point oracle.

### Already repaired in v7 — do not propose this again

The old path confused effect/producer eligibility with complete possible raster-color writes. An unrelated blended/line/masked/no-program/NONE draw could erase queued predecessors; partial MRT buffer-zero capture was also insufficient for invalidation.

The candidate separates `GlDrawWrites` from `GlTextureUsage`. Complete unrelated writes can preserve queued metadata but cannot create ownership. Unknown/partial/protected/bound-image/bindless writes remain conservative. In-flight writes remain conservative even when unrelated. The original capture deadline, namespace, two-frame TTL/eight-hop bounds and positive sampling qualification remain.

An authored Windows MinHook regression failed before repair, then passed after repair; software GL/GLES/ANGLE mip pixels and exact Off controls also pass. See the included evidence. **This has not been proved to be the cause of v6's game failure.**

### Current candidate: tested package, not game acceptance

Focused Windows 45106272297 and full shader/UI/software matrix 45106460327 passed at eafff51... . Nonpublishing package 45109432114 passed at b450acc...; both uploaded ZIPs were downloaded/hash/CRC checked and extracted on Windows. These are historical hosted test/readback results, not new execution by this packet and not game pixels.

The candidate has no installed game Off -> Strong -> Off acceptance yet. User reports shader removal; their read-only check found version.dll, dinput8.dll, BsiPotatoOriginal.dll absent beside the selected HD-Player.exe. That is not a complete import/module inventory. Do not ask them to install or rerun originals as part of this source review.

## Four focused questions

### 1. Upstream producer path: identify a new, exact rejection

Read `GameCandidate::find`, `GameDraw`, `GameTransfer`, `GlProducerRoute` and `GlTextureProvenance`.

For the ordered flow **material draw M -> named RBO R -> CopyTexSubImage2D into T -> selected presentation consumes T**, is there an otherwise-qualified sequence that loses a necessary observed link or rejects the next producer in this candidate? Spell out current provider/display/context/share observation, DRAW/READ route, source/destination generations, ordering and deadlines. Name the first refusing predicate and show an authored failing regression.

Separate this from: legitimately unobserved pre-bootstrap sharing, foreign/protected output, unsupported image/storage alias, the already-repaired unknown-output defect, or lack of proof that a texture is actually presented. A hypothetical game path is not a confirmed implementation defect.

### 2. Bound-state inspection: a concrete capability gap, not another DLL recipe

Read `GlTextureOverride::usage/begin/inspectMips`, `GlDrawCalls.h`, and WGL/EGL code-target discovery.

Which precise shader/binding/resource/API state could contain a real ordinary mip-color sample but stop before our supported sampler inspection? Consider current monolithic program versus program pipelines, sampler types/arrays, effective sampler-versus-texture parameters, supported normalized formats/views, exact draw entry addresses and shader lookup behavior. Do not assume BlueStacks uses any of these from the existence of an API.

If you find a gap, specify whether it is an explicitly unsupported capability or a defect within the supported contract; provide a minimal authored test and safe ownership/Off controls. Wider draw-signature coverage alone does not prove that every provider-specific address is hooked.

### 3. A bounded census that reports unknown honestly

There is **no complete bind/filter/image/FBO shadow-state tracker** in this implementation. Current pre-route counts are CPU-only; actual descriptor observations occur only on already-qualified routes. Do not base a no-query design on nonexistent shadow state.

What useful route-rejection accounting can be obtained from already-computed predicates without extra GL inspection, source changes, raw handle export, or adoption of foreign/protected resources? Define one count per callback versus provider attempt and alias/nested handling. Keep an explicit unknown category for unobserved mip/filter/size/FBO state.

If a richer shadow tracker is truly necessary, list the complete invalidation/coverage contract first (late bootstrap, DSA/multibind, sampler/texture mutations, storage/views, framebuffer attachments, failed/unproved calls, shared namespaces and reused IDs). No sampled/incomplete trace can establish that the game has no LOD-responsive resources. Do not implement a large process-wide tracker just to fill guessed categories.

### 4. Optimize without breaking live Off or state isolation

Private samplers are already bounded/cached by their supported full descriptor; source objects are not edited. Can a smaller verified change reduce repeated inspection/cache/diagnostic CPU work **without** leaving private samplers bound across draws, trusting stale descriptors, or skipping invalidation? Name the exact source location, required mutation/lifetime invalidation and regression controls. Do not claim zero draw cost or an FPS gain without measurement.

A swap-only timer omits draw/bind/transfer hook work. Propose accurate aggregation of optional-hook CPU time, excluding native original time and accounting for nested aliases, if it is needed. CPU timing is not GPU timing or total frame-time benefit. No per-draw GL query is automatically equivalent to glFinish.

## Original-DLL identity correction is resolved, not the next experiment

Known SHA-256 values:

- Intel Light A (bias-only 1.5): 25da83f0c7f5d6052e67e279cb427d20643593321405f017331ebd450e5fdcf8.
- Intel Strong / MSI4 forte B (bias-only 3): c956f2bd04b22212ecb8e65a0397c40addf64be136d8d1cd906e473661113554.
- MSI4 leve C (bias/minimum 1.5): 289e1eb34e815b886f4c2585c37efc78c489f58fd7b28942cfd5aeb1ec38b282.
- MSI5 Strong D (bias/minimum 3): 7440db72c09af59e8a3249e17fff0a1e964e4409bc6ec7b9c1686b35368fac22.
- MSI5 Light E (bias/minimum 1.5): b68e5b3586ffd2a57c680a0426818e71b06eadc3ce60b80507f42679892b3558.

If filenames such as dinput8_1.dll/version_1.dll are used in your analysis, a hash-to-name table suffices to identify them; do not re-upload or re-execute the originals. Prior contained authored-WGL tests covered all five identities and texture/sampler source modes. They do not establish this game's response.

Both desktop bias and minimum LOD are already in `begin`'s private policy; GLES is explicitly floor-only because desktop bias state is not legal there. Samplers also have wrap/comparison/border/extension state, which cannot silently revert to defaults.

The supplied PF archive's static loader handoff was already resolved: the player loads the private graphics provider, resolves/calls `grApiInit`, and hands the QML/parented native child-window through the private slot-zero route. Do not reopen the generic unknown-loader investigation or request the installer/Program Data. Static handoff evidence is not a runtime material-resource graph; no private offsets are to be called or hooked from it.

A negative original A/B without confirmed loading, actual entry coverage, API/context and effective sampling does **not** prove routing is irrelevant. Likewise apitrace/similar capture is bounded by interception/API/process/startup/extension coverage; it is not guaranteed to have no unknown state and can alter timing or contain private data. No new tracer injection/game-account/original-DLL execution is requested. Do not upload a raw game trace or disable protections.

## Run the small review-only tests (optional)

From this directory, with Python 3 and a local g++ or clang++:

```sh
python3 run_review_tests.py
python3 run_review_tests.py --sanitize
```

The first invocation builds/runs eight selected C++17 CPU/state-double contracts. `--sanitize` additionally requests ASan/UBSan/leak checking and requires compiler/runtime support. Output goes to `.review-build/` inside this review directory. There is no dependency download. The runner verifies all source/document member hashes against MANIFEST.json before building; reviewer edits require `--allow-edits` and are explicitly reported as edited, not still pinned.

These eight tests are **not** the full native/Vulkan suite, Windows MinHook execution, real GL driver pixels, Qt/native-player integration, an emulator/game run or an FPS measurement. The provided Windows/pixel test source may help construct a focused failing case for the main repository, but the review runner does not execute it.
