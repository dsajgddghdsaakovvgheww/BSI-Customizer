#!/usr/bin/env python3
"""Eight selected authored CPU/state-double tests; no downloads or player code."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TESTS = [
    ('gl-texture-safety', ['tests/shaders/gl_texture_override_test.cpp', 'src/shaders/GlTextureOverride.cpp', 'src/shaders/GlPipeline.cpp']),
    ('gl-texture-provenance', ['tests/shaders/gl_texture_provenance_test.cpp']),
    ('gl-deferred-copy-audit', ['tests/shaders/gl_deferred_copy_audit_test.cpp']),
    ('gl-producer-route', ['tests/shaders/gl_producer_route_test.cpp']),
    ('gl-draw-scope', ['tests/shaders/gl_draw_scope_test.cpp']),
    ('egl-dispatch-attribution', ['tests/shaders/egl_dispatch_scope_test.cpp']),
    ('wgl-pbuffer-registry', ['tests/shaders/wgl_pbuffer_registry_test.cpp']),
    ('renderer-routing', ['tests/shaders/renderer_capabilities_test.cpp', 'tests/shaders/runtime_hooks_stub.cpp', 'src/shaders/Runtime.cpp']),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sanitize', action='store_true')
    parser.add_argument('--allow-edits', action='store_true', help='Allow reviewed source changes; do not call those bytes pinned')
    parser.add_argument('--cxx', help='Local g++/clang++ executable; defaults to g++, then clang++')
    parser.add_argument('--jobs', type=int, default=2)
    args = parser.parse_args()
    if not 1 <= args.jobs <= 8:
        parser.error('--jobs must be 1 to 8')
    if sys.platform == 'win32':
        parser.error('This small runner is for a local POSIX g++/clang++ toolchain; supplied Windows fixtures are source-review only here')
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    changed = []
    for entry in manifest['files']:
        name = PurePosixPath(entry['path'])
        if name.is_absolute() or any(part in ('', '.', '..') for part in name.parts):
            raise RuntimeError('Unsafe manifest path')
        file = ROOT.joinpath(*name.parts)
        if file.is_symlink() or not file.is_file():
            raise RuntimeError('Missing or linked review member: ' + str(name))
        value = file.read_bytes()
        if len(value) != entry['bytes'] or hashlib.sha256(value).hexdigest() != entry['sha256']:
            changed.append(str(name))
    if changed and not args.allow_edits:
        raise RuntimeError('Review bytes differ from MANIFEST.json; use --allow-edits only for deliberate reviewer changes: ' + ', '.join(changed))
    print('Source verification:', 'EDITED REVIEW: ' + ', '.join(changed) if changed else 'all manifest member sizes/SHA-256 match', flush=True)
    compiler = shutil.which(args.cxx) if args.cxx else shutil.which('g++') or shutil.which('clang++')
    if not compiler:
        raise RuntimeError('A local C++17 compiler is required; this script never downloads one')
    mode = 'asan-ubsan' if args.sanitize else 'strict'
    build = ROOT / '.review-build' / mode
    build.mkdir(parents=True, exist_ok=True)
    flags = ['-std=c++17', '-Wall', '-Wextra', '-Werror', '-pedantic', '-pthread', '-I', str(ROOT / 'src/shaders')]
    flags += ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'] if args.sanitize else ['-O2']
    environment = os.environ.copy()
    if args.sanitize:
        environment['ASAN_OPTIONS'] = 'detect_leaks=1:halt_on_error=1'
        environment['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'

    def one(case):
        name, sources = case
        exe = build / name
        compile_command = [compiler, *flags, *[str(ROOT / x) for x in sources], '-o', str(exe)]
        compiled = subprocess.run(compile_command, cwd=ROOT, capture_output=True, text=True, timeout=120)
        (build / (name + '.compile.log')).write_text(compiled.stdout + compiled.stderr)
        if compiled.returncode:
            print('FAIL compile:', name, '\n' + (compiled.stdout + compiled.stderr)[-6000:], flush=True)
            return {'name': name, 'compiled': False, 'passed': False}
        result = subprocess.run([str(exe)], cwd=ROOT, env=environment, capture_output=True, text=True, timeout=120)
        (build / (name + '.run.log')).write_text(result.stdout + result.stderr)
        passed = result.returncode == 0
        print(('PASS' if passed else 'FAIL') + ': ' + name, flush=True)
        if not passed:
            print((result.stdout + result.stderr)[-6000:], flush=True)
        return {'name': name, 'compiled': True, 'passed': passed, 'exitCode': result.returncode}

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        results = list(pool.map(one, TESTS))
    report = {'scope': 'eight selected authored CPU/public-state-double contracts only',
              'notIncluded': ['Vulkan pixels/full native suite', 'Windows MinHook execution', 'real GL pixels', 'Qt/player/game/GPU/FPS acceptance'],
              'mode': mode, 'reviewEdits': changed, 'tests': results,
              'passed': sum(x['passed'] for x in results), 'total': len(results)}
    (build / 'review-results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f"{report['passed']}/{report['total']} selected review tests passed ({mode}); NOT game acceptance", flush=True)
    return 0 if all(x['passed'] for x in results) else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as error:
        print('Review test runner failed:', error, file=sys.stderr)
        raise SystemExit(1)
