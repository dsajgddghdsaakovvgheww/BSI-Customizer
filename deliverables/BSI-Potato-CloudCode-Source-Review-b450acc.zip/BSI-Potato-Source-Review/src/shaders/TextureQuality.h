#pragma once
#include "RendererCapabilities.h"
#include <algorithm>
#include <cmath>
#include <cstdint>

// Independently authored sampling policy, used by the explicit GL scene and
// owned-mip compatibility strategies. This is NOT a presentation filter. Callers
// must establish the resource contract and create a PRIVATE sampler replacement;
// never mutate a game's sampler or infer ownership from a loaded graphics DLL.
namespace BsiShaders {
enum class TextureQuality { Native, Light, Strong };
// Inspection outcomes, NOT proof of changed game pixels. Keeping these separate
// avoids a final UI/compositor draw hiding whether any scene samplers qualified.
enum class TextureDrawReason { NotInspected, Unreviewed, Primitive, Depth, Blended, NoSampler, Prepared, Policy };
// Depth is a scene heuristic, not a GL requirement for mip selection. The
// explicit compatibility policy accepts inspected mip-color bindings on the
// caller's EXACT owned game drawable without claiming semantic scene proof.
// Neither policy authorizes another drawable, provider, protected or Qt surface.
enum class TextureDrawPolicy { DepthQualifiedScene, OwnedMipCompatibility };
// First blocking depth check only. None also represents an older/external
// aggregate report without a subreason; it must not invent a queried GL state.
enum class TextureDepthFailure { None, TestDisabled, WritesDisabled, Never, Always, MissingAttachment, InsufficientPrecision, Count };
struct TextureConfiguration {
    bool enabled=false,externalOverridesReviewed=false;
    TextureDrawPolicy drawPolicy=TextureDrawPolicy::DepthQualifiedScene;
    // Saved percentage, independent of visual effects and render resolution.
    // 100 preserves the original On setting (up to 3 mip levels); 0 is native.
    int strength=100;
    bool valid()const{return strength>=0&&strength<=100;}
    bool active()const{return enabled&&valid()&&strength>0;}
    TextureQuality quality()const{return active()?TextureQuality::Strong:TextureQuality::Native;}
};
enum class TextureUse { Unknown, SampledColor, UserInterface, Depth, Integer, RenderTarget, Presentation };
struct TextureQualityProof {
    Renderer renderer=Renderer::Unknown;
    RendererFamily requested=RendererFamily::Automatic;
    TextureUse use=TextureUse::Unknown;
    bool gameSurfaceIdentified=false;
    // Caller evidence of use on its exact owned draw, not semantic albedo/UI
    // classification or proof of the object's complete creation/share history.
    bool resourceOwnershipProven=false;
    bool privateReplacementSupported=false;
    bool protectedContent=false;
    // GL queries cannot prove that all external driver-profile overrides are
    // absent. Unknown is a bypass, NOT permission to reset or guess a profile.
    bool externalOverridesReviewed=false;
    std::uint32_t visibleMipLevels=0;
};
struct TextureSampling {
    float minimumLod=0,maximumLod=0,lodBias=0;
    bool mipmapped=false,comparison=false,anisotropic=false,customReduction=false;
    bool unnormalizedCoordinates=false;
};
enum class TextureQualityDecision {
    Applied, Disabled, InvalidMode, UnidentifiedRenderer, UnqualifiedResource,
    UnsupportedReplacement, ProtectedContent, ExternalOverridesUnverified,
    NoMipChain, UnsupportedSampling, InvalidSampling, ExistingLodOverride,
    NoCoarserLevel, UnsupportedDescriptor, InvalidStrength
};
struct TextureQualityPlan {
    TextureSampling sampling;
    TextureQualityDecision decision;
    bool changed()const{return decision==TextureQualityDecision::Applied;}
};
inline TextureQualityPlan planTextureQuality(TextureQuality mode,const TextureQualityProof &proof,
                                             const TextureSampling &source,int strength=100){
    TextureQualityPlan plan{source,TextureQualityDecision::Disabled};
    const auto refuse=[&](TextureQualityDecision why){plan.decision=why;return plan;};
    if(mode==TextureQuality::Native)return plan;
    if(mode!=TextureQuality::Light&&mode!=TextureQuality::Strong)return refuse(TextureQualityDecision::InvalidMode);
    if(strength<0||strength>100)return refuse(TextureQualityDecision::InvalidStrength);
    if(!strength)return plan;
    if(!canRoute(proof.renderer,proof.gameSurfaceIdentified,true,proof.requested))return refuse(TextureQualityDecision::UnidentifiedRenderer);
    if(proof.use!=TextureUse::SampledColor||!proof.resourceOwnershipProven)return refuse(TextureQualityDecision::UnqualifiedResource);
    if(proof.protectedContent)return refuse(TextureQualityDecision::ProtectedContent);
    if(!proof.privateReplacementSupported)return refuse(TextureQualityDecision::UnsupportedReplacement);
    if(!proof.externalOverridesReviewed)return refuse(TextureQualityDecision::ExternalOverridesUnverified);
    if(proof.visibleMipLevels<2||proof.visibleMipLevels>32||!source.mipmapped)return refuse(TextureQualityDecision::NoMipChain);
    if(source.comparison||source.anisotropic||source.customReduction||source.unnormalizedCoordinates)
        return refuse(TextureQualityDecision::UnsupportedSampling);
    if(!std::isfinite(source.minimumLod)||!std::isfinite(source.maximumLod)||!std::isfinite(source.lodBias)
       ||source.minimumLod<0||source.maximumLod<source.minimumLod)
        return refuse(TextureQualityDecision::InvalidSampling);
    // Do not add our bias to an application's/profile's existing LOD policy.
    // A minimum-LOD floor also works in GLES 3, where texture LOD bias does not.
    if(source.minimumLod!=0||source.lodBias!=0)return refuse(TextureQualityDecision::ExistingLodOverride);
    const float last=static_cast<float>(proof.visibleMipLevels-1);
    const float ceiling=(std::min)(last,source.maximumLod);
    if(ceiling<=0)return refuse(TextureQualityDecision::NoCoarserLevel);
    const float requested=(mode==TextureQuality::Light?1.5f:3.f)*float(strength)/100.f;
    plan.sampling.minimumLod=(std::min)(requested,ceiling);
    plan.decision=TextureQualityDecision::Applied;
    return plan;
}
inline const char *textureQualityDiagnostic(TextureQualityDecision decision){
    switch(decision){
    case TextureQualityDecision::Applied:return "Private sampler minimum-LOD plan prepared; game integration and performance are not confirmed.";
    case TextureQualityDecision::Disabled:return "Native sampling retained.";
    case TextureQualityDecision::InvalidMode:return "Unknown texture-quality mode; native sampling retained.";
    case TextureQualityDecision::InvalidStrength:return "Texture strength must be an integer percentage from 0 to 100; native sampling retained.";
    case TextureQualityDecision::UnidentifiedRenderer:return "Game surface/API is unidentified or does not match the selected renderer.";
    case TextureQualityDecision::UnqualifiedResource:return "Only an ownership-proven sampled game-color resource qualifies.";
    case TextureQualityDecision::UnsupportedReplacement:return "A safe private sampler replacement is unavailable for this resource/API.";
    case TextureQualityDecision::ProtectedContent:return "Protected content is never modified.";
    case TextureQualityDecision::ExternalOverridesUnverified:return "External driver/profile overrides are unverified; native sampling retained.";
    case TextureQualityDecision::NoMipChain:return "No qualified mipmapped color view is available.";
    case TextureQualityDecision::UnsupportedSampling:return "Comparison, anisotropic, reduction or unnormalized sampling is not qualified.";
    case TextureQualityDecision::InvalidSampling:return "Invalid or nonfinite source LOD limits; native sampling retained.";
    case TextureQualityDecision::ExistingLodOverride:return "Existing minimum-LOD/bias overrides are preserved, not stacked or reset.";
    case TextureQualityDecision::NoCoarserLevel:return "The source sampler/view exposes no coarser LOD.";
    case TextureQualityDecision::UnsupportedDescriptor:return "Extended or unsupported sampler descriptor; native sampling retained.";
    }
    return "Unknown texture-quality decision; native sampling retained.";
}
template<typename Descriptor>struct TextureSamplerPlan {
    Descriptor descriptor;
    TextureQualityDecision decision;
    bool changed()const{return decision==TextureQualityDecision::Applied;}
};
} // namespace BsiShaders
