#include "Parameters.h"
#include "RendererCapabilities.h"
#include "Runtime.h"
#include <cstdio>
#include <cstdlib>
#include <atomic>
#include <thread>
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

using namespace BsiShaders;
namespace {
void require(bool condition,const char *message){
    if(!condition){std::fprintf(stderr,"FAIL: %s\n",message);std::exit(1);}
}
}
int main(){
    require(!canRoute(Renderer::Unknown,true,true),"loaded modules alone do not identify a renderer");
    for(const auto &entry:rendererCapabilities){
        require(!canRoute(entry.renderer,false,true),"Qt UI or unidentified surfaces cannot be routed");
        require(!canRoute(entry.renderer,true,false),"missing device capabilities cannot be ignored");
    }
    require(canRoute(Renderer::OpenGL,true,true,RendererFamily::OpenGL),"OpenGL candidate routing");
    require(canRoute(Renderer::OpenGLES,true,true,RendererFamily::OpenGL),"ANGLE/GLES follows the OpenGL setting");
    require(!canRoute(Renderer::OpenGL,true,true,RendererFamily::DirectX),"OpenGL cannot substitute for selected DirectX");
    require(!canRoute(Renderer::OpenGL,true,true,RendererFamily::Vulkan),"OpenGL cannot substitute for selected Vulkan");
    // The pipeline code now exists for all target families. This unit test is
    // NOT their certification: separate actual Vulkan and DirectX WARP pixel
    // tests must execute those production implementations successfully.
    require(capability(Renderer::Direct3D11).pipelineImplemented,"D3D11 pipeline routing is declared");
    require(capability(Renderer::Direct3D12).pipelineImplemented,"D3D12 pipeline routing is declared");
    require(capability(Renderer::Vulkan).pipelineImplemented,"Vulkan pipeline routing is declared");
    Parameters p;p.enabled=true;p.values[0]=20;
    auto &runtime=Runtime::instance();runtime.set(p);
    runtime.selectRenderer(RendererFamily::Vulkan);
    runtime.report(true,true,true,"must not be reported active",true,Renderer::Vulkan);
    auto m=runtime.metrics();
    require(!m.active&&!m.deviceReady&&m.processed==0,"an unvalidated Vulkan device cannot claim processed frames");
    require(m.renderer==Renderer::Vulkan,"observed API is not silently changed to OpenGL");
    require(!runtime.accepts(Renderer::OpenGL),"explicit Vulkan-only test policy rejects GL; this is NOT an emulator-config hint");
    runtime.set(Parameters{});
    require(runtime.metrics().status.find("not validated")!=std::string::npos,"neutral state must not hide an unvalidated-device diagnostic");
    runtime.selectRenderer(RendererFamily::DirectX);runtime.set(p);
    runtime.report(true,true,true,"must not be reported active",true,Renderer::Direct3D11);
    require(!runtime.metrics().active&&runtime.metrics().processed==0,"an unvalidated DX11 device must not count a frame");
    require(!runtime.accepts(Renderer::OpenGLES),"explicit DirectX-only test policy rejects GL/GLES, separate from automatic config hints");
    runtime.selectRenderer(RendererFamily::Automatic);
    runtime.report(true,false,true,"unidentified",true,Renderer::OpenGL,true);
    require(!runtime.metrics().active&&runtime.metrics().processed==0,"a surface must actually be identified");
    runtime.report(true,true,true,"identified OpenGL candidate with validated features",true,Renderer::OpenGLES,true);
    require(runtime.metrics().active&&runtime.metrics().processed==1,"identified implemented family can report a processed frame");
    runtime.report(true,true,true,"underlying ANGLE DXGI present",true,Renderer::Direct3D11,true);
    require(runtime.metrics().renderer==Renderer::OpenGLES&&runtime.metrics().processed==1,
            "auto selection prevents double-processing through ANGLE's underlying DXGI layer");
    runtime.waiting(true,"stale worker scan");
    require(runtime.metrics().active&&runtime.metrics().processed==1,"a stale waiting scan must not erase a newer confirmed game frame");
    runtime.vulkanEvent(VulkanEvent::LoaderHooked,"authored-test-provider.dll");
    require(runtime.metrics().renderer==Renderer::OpenGLES&&runtime.metrics().processed==1,"Vulkan lifecycle evidence is not an observed game API or another processed frame");
    runtime.set(Parameters{});
    require(!runtime.metrics().active,"disabled/neutral settings report no active effects");
    runtime.report(true,true,true,"neutral frame",true,Renderer::OpenGLES,true);
    require(runtime.metrics().processed==1,"neutral bypass cannot count as an effect pass");
    VulkanCapture capture;
    require(capture.waiting().find("no complete Vulkan loader")!=std::string::npos,"missing-loader diagnostic");
    capture.note(VulkanEvent::LoaderHooked,"first.dll");
    require(capture.waiting().find("no instance creation")!=std::string::npos,"late lifecycle is diagnosed before shader compilation");
    capture.note(VulkanEvent::InstanceCreated);
    require(capture.waiting().find("device/queue")!=std::string::npos,"instance alone does not prove a device");
    capture.note(VulkanEvent::DeviceRejected,"missing public device entry point");
    require(capture.waiting()=="missing public device entry point","retain an actionable device-capture blocker");
    capture.note(VulkanEvent::DeviceTracked);
    require(capture.waiting().find("no Win32")!=std::string::npos,"non-Win32 surfaces are not guessed");
    capture.note(VulkanEvent::SurfaceCreated);capture.note(VulkanEvent::SwapchainTracked);
    capture.note(VulkanEvent::Presented);capture.note(VulkanEvent::WindowRejected,"Qt UI excluded");
    require(capture.waiting()=="Qt UI excluded"&&capture.rejectedWindows==1,"ownership failures have a distinct diagnostic");
    runtime.selectRenderer(RendererFamily::Vulkan);
    runtime.vulkanEvent(VulkanEvent::QueueMissed,"device predates capture; restart required");
    runtime.waiting(true,"generic scan must not hide the Vulkan stage");
    require(!runtime.metrics().observed&&!runtime.metrics().active&&runtime.metrics().processed==1
            &&runtime.metrics().status.find("no instance creation")!=std::string::npos,
            "loader/stage diagnostics never fabricate observed game frames or weaken routing");
#ifdef _WIN32
    const auto root=CreateWindowExW(0,L"STATIC",L"routing unit root",WS_OVERLAPPEDWINDOW,0,0,900,600,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    const auto child=CreateWindowExW(0,L"STATIC",L"routing unit game",WS_CHILD,0,0,640,480,root,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(root&&child,"create live routing-unit HWND identities");
    runtime.setWindow(reinterpret_cast<std::uintptr_t>(root));
    const auto window=reinterpret_cast<std::uintptr_t>(child);
    require(runtime.eligible(window)&&!runtime.eligible(reinterpret_cast<std::uintptr_t>(root)),"only the live game child passes native ownership/size gates, never the root UI");
#else
    const std::uintptr_t window=303;
#endif
    for(const auto hint:{RendererFamily::OpenGL,RendererFamily::DirectX,RendererFamily::Vulkan,RendererFamily::Automatic}){
        runtime.configureRenderer(hint);runtime.set(p);
        const auto before=runtime.metrics().processed;
        runtime.vulkanEvent(VulkanEvent::DeviceTracked);
        require(runtime.accepts(Renderer::OpenGLES)&&runtime.accepts(Renderer::Direct3D11)&&runtime.accepts(Renderer::Vulkan)
                &&!runtime.metrics().observed,"every configured/unknown hint keeps all actual presentation APIs eligible; a Vulkan device alone cannot lock routing");
        require(!runtime.claimPresentation(Renderer::Unknown,11,window)&&!runtime.claimPresentation(Renderer::OpenGL,0,window),"invalid presentation identities cannot claim a route");
        require(runtime.claimPresentation(Renderer::OpenGLES,11,window),"actual owned GLES presentation can claim even under a Vulkan hint");
        require(!runtime.claimPresentation(Renderer::Direct3D11,33,window)&&!runtime.claimPresentation(Renderer::OpenGL,44,window)
                &&!runtime.claimPresentation(Renderer::OpenGLES,55,window),"arbitration precedes processing, rejecting nested cross-family AND same-family translation providers");
        runtime.report(true,true,true,"actual GLES pass",true,Renderer::OpenGLES,true);
        require(runtime.metrics().requested==RendererFamily::Automatic&&runtime.metrics().configured==hint
                &&runtime.metrics().renderer==Renderer::OpenGLES&&runtime.metrics().processed==before+1,"hint and actual game API remain distinct; only the actual pass increments counters");
        runtime.releasePresentation(Renderer::OpenGL,11);
        require(!runtime.accepts(Renderer::Vulkan),"the wrong renderer cannot revoke another source's arbitration token");
        runtime.releasePresentation(Renderer::OpenGLES,11);
        require(runtime.accepts(Renderer::Vulkan)&&!runtime.metrics().observed,"destroying the selected game source re-arms automatic detection");
        require(runtime.claimPresentation(Renderer::Vulkan,66,window),"a replacement native Vulkan source can be adopted after old GLES teardown");
        runtime.releasePresentation(Renderer::Vulkan,66);
    }
    runtime.configureRenderer(RendererFamily::Vulkan);
    std::atomic<unsigned> claims{0};
    std::thread a([&]{if(runtime.claimPresentation(Renderer::OpenGLES,101,window))++claims;});
    std::thread b([&]{if(runtime.claimPresentation(Renderer::Direct3D11,202,window))++claims;});
    a.join();b.join();require(claims==1,"concurrent presentation callbacks must claim exactly one source BEFORE either backend can process pixels");
    runtime.configureRenderer(RendererFamily::Automatic);runtime.setTexture({true,true});
    require(!runtime.isPresentation(Renderer::OpenGLES,901,window)&&!runtime.metrics().observed,
            "a read-only draw authorization check cannot claim an unobserved route");
    runtime.textureReport(3,"unobserved must not count",true,TextureDrawReason::Prepared);
    require(!runtime.metrics().textureDraws&&!runtime.metrics().textureInspected,"no presentation means no texture evidence, even if a stale callback tries to report bindings");
    require(runtime.claimPresentation(Renderer::OpenGLES,901,window)&&runtime.isPresentation(Renderer::OpenGLES,901,window)
            &&!runtime.isPresentation(Renderer::OpenGLES,902,window)&&!runtime.isPresentation(Renderer::OpenGL,901,window),
            "draw authorization requires the already-selected renderer, presentation identity and exact game window");
    runtime.textureReport(0,"armed only",true);
    require(!runtime.metrics().textureInspected&&!runtime.metrics().textureDraws,"hook availability is not an inspected or prepared scene call");
    runtime.textureReport(0,"compositor depth bypass",true,TextureDrawReason::Depth,TextureDepthFailure::TestDisabled);
    runtime.textureReport(0,"scene without mip samplers",true,TextureDrawReason::NoSampler);
    runtime.textureReport(2,"private scene preparation",true,TextureDrawReason::Prepared,TextureDepthFailure::None,true);
    runtime.textureReport(0,"later UI bypass",true,TextureDrawReason::Blended);
    m=runtime.metrics();
    require(m.textureInspected==4&&m.textureSceneDraws==2&&m.textureDraws==1&&m.textureBindings==2
            &&m.textureDepthBypasses==1&&m.textureBlendBypasses==1&&m.textureSamplerBypasses==1
            &&m.textureDepthReasons[static_cast<std::size_t>(TextureDepthFailure::TestDisabled)]==1
            &&m.textureNestedInspected==1&&m.textureNestedDraws==1
            &&m.textureStatus=="private scene preparation"&&m.textureLastBypass=="later UI bypass",
            "aggregate/depth/nested evidence is truthful and a final HUD call does not erase earlier real sampler preparation");
    for(std::size_t i=0;i<static_cast<std::size_t>(TextureDepthFailure::Count);++i)
        runtime.textureReport(0,"separate first depth blocker",true,TextureDrawReason::Depth,static_cast<TextureDepthFailure>(i),true);
    runtime.textureReport(0,"unknown depth reason stays unspecified",true,TextureDrawReason::Depth,static_cast<TextureDepthFailure>(999));
    const auto beforeUninspected=runtime.metrics().textureNestedInspected;
    runtime.textureReport(0,"armed is not inspected",true,TextureDrawReason::NotInspected,TextureDepthFailure::Always,true);
    m=runtime.metrics();std::uint64_t depthSum=0;for(const auto count:m.textureDepthReasons)depthSum+=count;
    require(depthSum==m.textureDepthBypasses&&m.textureDepthReasons[0]==2&&m.textureNestedInspected==beforeUninspected
            &&m.textureNestedDraws==1,"first-blocker categories sum exactly to the aggregate; unreported/invalid reasons stay bounded and arming cannot count as a nested scene call");
    const auto framesBeforePolicy=runtime.metrics().processed;
    runtime.setTexture({true,true,TextureDrawPolicy::OwnedMipCompatibility});
    m=runtime.metrics();
    require(m.texturePolicy==TextureDrawPolicy::OwnedMipCompatibility&&!m.textureInspected&&!m.textureDraws
            &&!m.textureDepthBypasses&&m.textureDepthReasons==decltype(m.textureDepthReasons){}
            &&m.processed==framesBeforePolicy&&runtime.isPresentation(Renderer::OpenGLES,901,window),
            "policy-only change resets texture evidence atomically, preserves the exact selected source and does not invent presentation frames");
    const auto route=runtime.textureRoute();
    require(route.configuration.enabled&&route.renderer==Renderer::OpenGLES&&route.object==901&&route.window==window,
            "dependency routing has one mutex-consistent settings/source identity, never a draw-selected presentation");
    GlTransferAttempt attempt;attempt.revision=route.revision;attempt.providers=1;
    attempt.stop=GlTransferStop::Descriptor;attempt.descriptor=GlTransferDescriptor::Framebuffer;
    attempt.candidates[static_cast<std::size_t>(GlCandidateStop::Qualified)]=1;
    runtime.textureTransferAuditReport(attempt);
    auto audit=runtime.metrics().textureTransferAudit;
    require(audit.calls[0]==1&&audit.stops[static_cast<std::size_t>(GlTransferStop::Descriptor)]==1
            &&audit.descriptors[static_cast<std::size_t>(GlTransferDescriptor::Framebuffer)]==1
            &&audit.candidates[static_cast<std::size_t>(GlCandidateStop::Qualified)]==1&&audit.codeProviders[0]==1
            &&!runtime.metrics().textureInspected&&!runtime.metrics().textureTransferCalls&&!runtime.metrics().textureProducerDraws,
            "transfer rejection diagnostics never count as qualified ownership, inspected draws or successful copies");
    runtime.textureDeferredCopyReport(1,1,route.revision);
    runtime.textureDeferredCopyReport(100,100,0);
    require(runtime.metrics().textureDeferredCopies==1&&runtime.metrics().textureDeferredInputs==1
            &&!runtime.metrics().textureTransferCalls&&!runtime.metrics().textureProducerDraws&&!runtime.metrics().textureBindings,
            "late submitted-copy reconciliation is separate from native calls, ownership/private binding counts and invalid epochs");
    GlDeferredCopyAudit pendingSnapshot;pendingSnapshot.sequence=1;pendingSnapshot.queued=pendingSnapshot.pending=pendingSnapshot.peak=1;pendingSnapshot.sources[2]=1;
    runtime.textureDeferredAuditReport(pendingSnapshot,0);
    require(!runtime.metrics().textureDeferredAudit.sequence,"pending snapshot without a source epoch is never published");
    runtime.textureDeferredAuditReport(pendingSnapshot,route.revision);
    require(runtime.metrics().textureDeferredAudit.pending==1&&runtime.metrics().textureDeferredAudit.queued==1
            &&runtime.metrics().textureDeferredCopies==1&&!runtime.metrics().textureTransferCalls&&!runtime.metrics().textureBindings,
            "admitted pending metadata is a separate cumulative diagnostic snapshot, not another native call or prepared effect");
    auto invalidSnapshot=pendingSnapshot;invalidSnapshot.sequence=2;invalidSnapshot.pending=33;
    runtime.textureDeferredAuditReport(invalidSnapshot,route.revision);
    invalidSnapshot=pendingSnapshot;invalidSnapshot.sequence=2;invalidSnapshot.sources={};runtime.textureDeferredAuditReport(invalidSnapshot,route.revision);
    invalidSnapshot={};invalidSnapshot.sequence=2;invalidSnapshot.peak=1;runtime.textureDeferredAuditReport(invalidSnapshot,route.revision);
    require(runtime.metrics().textureDeferredAudit.sequence==1,"invalid gauge, impossible peak or unbalanced source/exit accounting cannot replace a valid snapshot");
    const auto snapshots=[&](unsigned start,bool expired){
        for(unsigned i=1;i<=100;++i){
            auto sample=pendingSnapshot;sample.sequence=start+i;
            if(expired){sample.pending=0;sample.exits[static_cast<std::size_t>(GlDeferredCopyExit::Expired)]=1;}
            runtime.textureDeferredAuditReport(sample,route.revision);
        }
    };
    std::thread snapshotA(snapshots,100,false),snapshotB(snapshots,200,true);snapshotA.join();snapshotB.join();
    runtime.textureDeferredAuditReport(pendingSnapshot,route.revision);
    require(runtime.metrics().textureDeferredAudit.sequence==300&&runtime.metrics().textureDeferredAudit.queued==1
            &&!runtime.metrics().textureDeferredAudit.pending&&runtime.metrics().textureDeferredCopies==1,
            "out-of-order/concurrent snapshots keep the newest sequence; they are NEVER summed or allowed to replay an old pending gauge");
    attempt.api=999;runtime.textureTransferAuditReport(attempt);
    require(runtime.metrics().textureTransferAudit.calls==audit.calls,"unrecognized transfer audit enums are bounded before indexing");
    attempt.api=GlColorTransfer::CopyTexSubImage2D;attempt.providers=2;attempt.stop=GlTransferStop::NoCandidate;attempt.candidates={};
    attempt.candidates[static_cast<std::size_t>(GlCandidateStop::Renderer)]=1;
    attempt.candidates[static_cast<std::size_t>(GlCandidateStop::Dependency)]=1;
    runtime.textureTransferAuditReport(attempt);
    audit=runtime.metrics().textureTransferAudit;
    require(audit.calls[1]==1&&audit.codeProviders[1]==1&&audit.candidates[static_cast<std::size_t>(GlCandidateStop::Renderer)]==1
            &&audit.candidates[static_cast<std::size_t>(GlCandidateStop::Dependency)]==1,
            "retain each shared-code provider candidate's refusal separately, not a misleading arbitrary last candidate");
    attempt.api=GlColorTransfer::CopyImage;attempt.providers=3;attempt.stop=GlTransferStop::Busy;attempt.candidates={};
    const auto report=[&]{for(unsigned i=0;i<100;++i){runtime.textureTransferAuditReport(attempt);runtime.textureDeferredCopyReport(1,1,route.revision);}};
    std::thread diagnosticA(report);
    std::thread diagnosticB(report);
    diagnosticA.join();diagnosticB.join();audit=runtime.metrics().textureTransferAudit;
    require(audit.calls[2]==200&&audit.codeProviders[2]==200&&audit.stops[static_cast<std::size_t>(GlTransferStop::Busy)]==200
            &&runtime.metrics().textureDeferredCopies==201&&runtime.metrics().textureDeferredInputs==201,
            "concurrent diagnostic aggregation remains mutex-consistent without claiming a captured transfer");
    for(const auto *label:glTransferLabels)require(label&&*label,"all terminal diagnostic categories have stable labels");
    for(const auto *label:glCandidateLabels)require(label&&*label,"all candidate diagnostic categories have stable labels");
    for(const auto *label:glDescriptorLabels)require(label&&*label,"all descriptor diagnostic categories have stable labels");
    for(const auto kind:{TextureHookKind::Draw,TextureHookKind::ColorTransfer,TextureHookKind::NamedImageCopy,TextureHookKind::NativeImageBinding})
        require(runtime.textureHookEntry(kind),"active hook-entry settings read remains independent of route qualification");
    m=runtime.metrics();
    require(m.textureHookDrawCalls==1&&m.textureHookTransferCalls==3&&m.textureHookImageCopyCalls==1&&m.textureHookNativeImageCalls==1
            &&!m.textureInspected&&!m.textureTransferCalls&&!m.textureProducerDraws,
            "raw hook coverage must never masquerade as owned inspection, qualified transfers or prepared material bindings");
    runtime.textureConsumerReport(1,route.revision);runtime.textureTransferReport(1,route.revision);
    runtime.textureReport(2,"depth-independent private mip preparation",true,TextureDrawReason::Prepared,TextureDepthFailure::None,false,true,route.revision);
    m=runtime.metrics();
    require(m.textureDraws==1&&m.textureDepthBypasses==0&&m.textureConsumerDraws==1&&m.textureConsumerInputs==1
            &&m.textureProducerInspected==1&&m.textureProducerDraws==1&&m.textureProducerBindings==2
            &&m.textureTransferCalls==1&&m.textureTransferInputs==1&&m.processed==framesBeforePolicy
            &&m.textureProducerStatus=="depth-independent private mip preparation",
            "submitted color transfers and producer bindings are separate evidence, not extra draws, a manufactured depth predicate or processed frame");
    runtime.textureReport(0,"producer: unsupported color internal format",true,TextureDrawReason::NoSampler,TextureDepthFailure::None,false,true,route.revision);
    runtime.textureReport(0,"later compositor: single level",true,TextureDrawReason::NoSampler,TextureDepthFailure::None,false,false,route.revision);
    require(runtime.metrics().textureProducerStatus=="producer: unsupported color internal format"
            &&runtime.metrics().textureProducerInspected==2&&runtime.metrics().textureLastBypass=="later compositor: single level",
            "retain the real producer's precise refusal separately; a later compositor must not overwrite it with a misleading no-mip diagnosis");
    runtime.setTexture({true,true,TextureDrawPolicy::OwnedMipCompatibility,50});
    const auto halfRoute=runtime.textureRoute();m=runtime.metrics();
    runtime.textureTransferAuditReport(attempt);runtime.textureDeferredCopyReport(50,50,route.revision);runtime.textureDeferredAuditReport(pendingSnapshot,route.revision);
    require(runtime.metrics().textureTransferAudit.calls==decltype(audit.calls){}
            &&runtime.metrics().textureTransferAudit.stops==decltype(audit.stops){}
            &&!runtime.metrics().textureDeferredCopies&&!runtime.metrics().textureDeferredInputs&&!runtime.metrics().textureDeferredAudit.sequence,
            "strength/source resets clear the full routing ledger and reject late old-epoch diagnostic reports");
    std::uint64_t hookRevision=0;
    require(runtime.textureHookEntry(TextureHookKind::Draw,&hookRevision)&&hookRevision==halfRoute.revision,
            "hook entry captures the same mutex-consistent revision as raw counters");
    runtime.setTexture({false,true,TextureDrawPolicy::OwnedMipCompatibility,50});
    require(!runtime.textureHookEntry(TextureHookKind::Draw,&hookRevision)&&!hookRevision,
            "Off zeroes even a previously nonzero diagnostic epoch token");
    runtime.textureDeferredAuditReport(pendingSnapshot,runtime.textureRoute().revision);
    require(!runtime.metrics().textureDeferredAudit.sequence,"Off rejects even a current-epoch pending audit snapshot");
    runtime.setTexture({true,true,TextureDrawPolicy::OwnedMipCompatibility,50});
    require(halfRoute.revision!=route.revision&&halfRoute.configuration.strength==50&&!m.textureInspected&&!m.textureBindings&&m.textureProducerStatus.empty()
            &&!m.textureHookDrawCalls&&!m.textureHookTransferCalls&&!m.textureHookImageCopyCalls&&!m.textureHookNativeImageCalls,
            "strength-only Save invalidates old producer/provenance/counter evidence but keeps the selected source");
    runtime.textureReport(2,"old 100 percent draw",true,TextureDrawReason::Prepared,TextureDepthFailure::None,false,true,route.revision);
    require(!runtime.metrics().textureInspected,"an old-strength asynchronous result cannot masquerade as current-strength success");
    runtime.setTexture({true,true,TextureDrawPolicy::OwnedMipCompatibility,0});
    const auto zeroRevision=runtime.textureRoute().revision;
    require(!runtime.textureHookEntry(TextureHookKind::Draw)&&!runtime.textureHookEntry(TextureHookKind::NamedImageCopy)
            &&!runtime.metrics().textureHookDrawCalls&&!runtime.metrics().textureHookTransferCalls,"zero strength cannot collect active raw capture counters");
    runtime.textureConsumerReport(1,zeroRevision);runtime.textureTransferReport(1,zeroRevision);runtime.textureDeferredCopyReport(1,1,zeroRevision);runtime.textureDeferredAuditReport(pendingSnapshot,zeroRevision);
    runtime.textureReport(2,"zero is not a weak preparation",true,TextureDrawReason::Prepared,TextureDepthFailure::None,false,true,zeroRevision);
    require(!runtime.texture().active()&&!runtime.metrics().textureInspected&&!runtime.metrics().textureConsumerDraws
            &&!runtime.metrics().textureTransferCalls&&!runtime.metrics().textureDeferredCopies&&!runtime.metrics().textureDeferredInputs&&!runtime.metrics().textureDeferredAudit.sequence
            &&runtime.metrics().textureStatus.find("0%")!=std::string::npos,"zero strength is explicit native sampling, not an unconfirmed small effect");
    runtime.setTexture({true,true,TextureDrawPolicy::OwnedMipCompatibility,101});
    require(runtime.texture().strength==0&&runtime.textureRoute().revision==zeroRevision,"invalid runtime percentages cannot alter the current setting or evidence revision");
    runtime.setTexture({false,true,TextureDrawPolicy::OwnedMipCompatibility});
    runtime.setTexture({true,true,TextureDrawPolicy::OwnedMipCompatibility});
    require(runtime.textureRoute().revision!=route.revision,"Off->On changes dependency revision even when the exact same source/settings resume");
    runtime.textureConsumerReport(1,route.revision);runtime.textureTransferReport(1,route.revision);
    runtime.textureReport(2,"stale asynchronous producer result",true,TextureDrawReason::Prepared,TextureDepthFailure::None,false,true,route.revision);
    m=runtime.metrics();
    require(!m.textureInspected&&!m.textureConsumerDraws&&!m.textureConsumerInputs&&!m.textureProducerInspected
            &&!m.textureProducerDraws&&!m.textureProducerBindings&&!m.textureTransferCalls&&!m.textureTransferInputs&&m.textureProducerStatus.empty(),
            "old-revision reports cannot resurrect transfer/dependency/preparation evidence or a stale producer diagnosis after Off->On");
    runtime.setTexture({true,true});
    require(runtime.metrics().texturePolicy==TextureDrawPolicy::DepthQualifiedScene&&!runtime.metrics().textureInspected,
            "changing back to conservative scope also starts a new evidence interval");
    runtime.setTexture({false,true});runtime.textureReport(2,"off must not count",true,TextureDrawReason::Prepared);
    m=runtime.metrics();
    require(!m.textureDraws&&!m.textureInspected&&!m.textureSupported&&!m.textureNestedInspected&&!m.textureNestedDraws
            &&m.textureDepthReasons==decltype(m.textureDepthReasons){},
            "off clears old depth/nested/preparation evidence instead of reusing lifetime sampler counts");
    runtime.setTexture({true,true});runtime.textureReport(1,"new enabled preparation",true,TextureDrawReason::Prepared,TextureDepthFailure::None,true);
    runtime.textureReport(0,"new source depth bypass",true,TextureDrawReason::Depth,TextureDepthFailure::Always,true);
    require(runtime.metrics().textureDraws==1&&runtime.metrics().textureNestedInspected==2,"on starts a new evidence interval");
    runtime.textureReport(0,"new source producer refusal",true,TextureDrawReason::NoSampler,TextureDepthFailure::None,false,true);
    runtime.releasePresentation(Renderer::OpenGLES,901);
    runtime.textureDeferredAuditReport(pendingSnapshot,runtime.textureRoute().revision);
    require(!runtime.metrics().textureDeferredAudit.sequence,"an unobserved source cannot publish current-epoch pending diagnostics");
    m=runtime.metrics();
    require(!runtime.isPresentation(Renderer::OpenGLES,901,window)&&!m.textureDraws&&!m.textureBindings
            &&!m.textureNestedInspected&&!m.textureNestedDraws&&m.textureDepthReasons==decltype(m.textureDepthReasons){}
            &&m.textureLastBypass.empty()&&m.textureProducerStatus.empty(),"source destruction revokes scene authorization and every depth/nested/preparation counter/last bypass/producer diagnosis");
    require(runtime.claimPresentation(Renderer::Direct3D11,903,window),"another actual renderer can replace the destroyed GL source");
    runtime.textureDeferredAuditReport(pendingSnapshot,runtime.textureRoute().revision);
    require(!runtime.metrics().textureDeferredAudit.sequence,"a D3D presentation cannot inherit GL pending-copy diagnostics");
    runtime.textureReport(4,"a presentation shader is not a D3D texture implementation",true,TextureDrawReason::Prepared);
    require(!runtime.metrics().textureDraws&&!runtime.metrics().textureSupported,"missing D3D/Vulkan texture binding implementation cannot be reported as successful");
    runtime.releasePresentation(Renderer::Direct3D11,903);runtime.setTexture({});
    runtime.configureRenderer(RendererFamily::Automatic);
#ifdef _WIN32
    DestroyWindow(child);DestroyWindow(root);
#endif
    for(std::size_t i=0;i<controls.size();++i){
        Parameters v;v.enabled=true;v.values[i]=controls[i].minimum;
        require(v.valid(),"minimum value validation");
        v.values[i]=controls[i].maximum;require(v.valid(),"maximum value validation");
        v.values[i]=controls[i].maximum+1;require(!v.valid(),"out of range validation");
    }
    std::puts("PASS: automatic actual-presentation routing across all config hints, concurrent/nested/same-family arbitration and source-teardown re-detection, explicit backend qualification, actual-surface and device-feature gating, no ANGLE double-processing, no unvalidated success counters, strict neutral bypass and value bounds");
}
