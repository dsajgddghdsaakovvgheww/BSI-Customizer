@echo off
call "%~dp0RUN-UI.cmd" --diagnose-ui --diagnostic-output "%~dp0VOID-UI-Diagnostics.zip" %*
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
