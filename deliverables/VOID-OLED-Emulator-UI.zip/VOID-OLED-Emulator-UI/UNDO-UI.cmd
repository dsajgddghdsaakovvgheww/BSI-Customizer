@echo off
call "%~dp0RUN-UI.cmd" --restore-latest --report "%~dp0UI-COVERAGE.json" %*
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
